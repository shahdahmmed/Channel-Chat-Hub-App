import 'package:firebase_database/firebase_database.dart';
import 'package:flutterapp1/message_model.dart';
import 'package:uuid/uuid.dart';


class ChatService {
  final FirebaseDatabase _database = FirebaseDatabase.instance;

  // Send a message to a specific channel
  Future<void> sendMessage({
    required String channelId,
    required String senderId,
    required String senderName,
    required String content,
  }) async {
    final messageId = const Uuid().v4();
    final message = ChatMessage(
      id: messageId,
      senderId: senderId,
      senderName: senderName,
      content: content,
      timestamp: DateTime.now(),
    );

    await _database
        .ref('channel_messages/$channelId')
        .push()
        .set(message.toRealtimeDatabase());
  }

  // Get messages for a specific channel
  Stream<List<ChatMessage>> getChannelMessages(String channelId) {
    return _database
        .ref('channel_messages/$channelId')
        .orderByChild('timestamp')
        .onValue
        .map((event) {
      final Map<dynamic, dynamic>? messagesMap = 
          event.snapshot.value as Map<dynamic, dynamic>?;

      if (messagesMap == null) return <ChatMessage>[];

      return messagesMap.entries.map((entry) {
        return ChatMessage.fromRealtimeDatabase(
          Map<String, dynamic>.from(entry.value)
        );
      }).toList();
    });
  }
}
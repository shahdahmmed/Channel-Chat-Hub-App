import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutterapp1/channel_model.dart';
import 'package:uuid/uuid.dart';

class ChannelService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Create a new channel
  Future<Channel> createChannel({
    required String name, 
    required String creatorId,
  }) async {
    final channelId = const Uuid().v4();
    final channel = Channel(
      id: channelId,
      name: name,
      subscribedUserIds: [creatorId],
    );

    await _firestore.collection('channels').doc(channelId).set(channel.toFirestore());
    return channel;
  }

  // Subscribe to a channel
  Future<void> subscribeToChannel(String channelId, String userId) async {
    await _firestore.collection('channels').doc(channelId).update({
      'subscribedUserIds': FieldValue.arrayUnion([userId])
    });
  }

  // Unsubscribe from a channel
  Future<void> unsubscribeFromChannel(String channelId, String userId) async {
    await _firestore.collection('channels').doc(channelId).update({
      'subscribedUserIds': FieldValue.arrayRemove([userId])
    });
  }

  // Get all channels
  Stream<List<Channel>> getChannels() {
    return _firestore.collection('channels')
        .snapshots()
        .map((snapshot) => snapshot.docs
        .map((doc) => Channel.fromFirestore(doc))
        .toList());
  }

  // Get user's subscribed channels
  Stream<List<Channel>> getUserChannels(String userId) {
    return _firestore.collection('channels')
        .where('subscribedUserIds', arrayContains: userId)
        .snapshots()
        .map((snapshot) => snapshot.docs
        .map((doc) => Channel.fromFirestore(doc))
        .toList());
  }
}
import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'channel_model.dart';
import 'channel_service.dart';

class AppProvider with ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final ChannelService _channelService = ChannelService();

  User? get currentUser => _auth.currentUser;
  
  Stream<List<Channel>> getUserChannels() {
    if (currentUser == null) {
      return Stream.value([]);
    }
    return _channelService.getUserChannels(currentUser!.uid);
  }

  Future<void> createChannel(String name, String description) async {
    if (currentUser == null) {
      throw Exception('User must be logged in to create a channel');
    }
    
    await _channelService.createChannel(
      name: name,  
      creatorId: currentUser!.uid
    );
    notifyListeners();
  }

  Future<void> subscribeToChannel(String channelId) async {
    if (currentUser == null) {
      throw Exception('User must be logged in to subscribe to a channel');
    }
    
    await _channelService.subscribeToChannel(channelId, currentUser!.uid);
    notifyListeners();
  }

  Future<void> unsubscribeFromChannel(String channelId) async {
    if (currentUser == null) {
      throw Exception('User must be logged in to unsubscribe from a channel');
    }
    
    await _channelService.unsubscribeFromChannel(channelId, currentUser!.uid);
    notifyListeners();
  }
}